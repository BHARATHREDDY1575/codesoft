# CODSOFT August Batch-3
All the tasks done during the Python Programming Internship at CodSoft
